<div class="card shadow contact p-4">
    <div class="card-body">
        <h5 class="text-white fs-5">REACH OUT TO US</h5>
        <p class="fs-5">Got a question about our programs?<br>Interested in partnering with us?</p>
        <p class="fs-5">Got suggestions ?</p>
        <p class="fs-5"> <i class="bi bi-telephone"></i> &nbsp;&nbsp; <span>+91 703 456 2050</span></p>
        <p class="fs-5"><i class="bi bi-envelope"></i>&nbsp;&nbsp; <span> ask@codecruise.in</span></p>
        <p class="fs-5"><i class="bi bi-geo-alt"></i>&nbsp;&nbsp; <span> A74, TechnoPark, Andheri, Mumbai,
                Maharashtra India.</span></p>
    </div>
</div>