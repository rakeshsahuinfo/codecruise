<div class=" mega-menu d-hidden shadow " id="mega-menu" onmouseleave="pronon()">
    <div class="navbar">
        <ul>
            <li><a class="nav-link scrollto" href="{{route('course','programming-fundamental')}}">Programming Fundamentals</a></li>
            <li><a class="nav-link scrollto" href="{{route('course','fullstack-python')}}">Full Stack Python</a></li>
            <li><a class="nav-link scrollto" href="{{route('course','software-testing')}}">Software Testing</a></li>
            <li><a class="nav-link scrollto" href="{{route('course','dbms')}}">DBMS and DBA</a></li>
            <li><a class="nav-link scrollto" href="{{route('course','net-development')}}">.NET Development</a></li>
            <li><a class="nav-link scrollto" href="{{route('course','fullstack-(mean)')}}">Full Stack (MEAN)</a></li>
            <li><a class="nav-link scrollto" href="{{route('course','devops-engineer')}}">DevOps Engineer</a></li>
            <li><a class="nav-link scrollto" href="{{route('course','fullstack-php')}}">Full Stack PHP</a></li>
            <li><a class="nav-link scrollto" href="{{route('course','java-development')}}">Full Stack JAVA</a></li>
            <li><a class="nav-link scrollto" href="{{route('course','fullstack-mern')}}">Full Stack (MERN)</a></li>
            <li><a class="nav-link scrollto" href="{{route('course','cloud-development')}}">Cloud Development</a></li>
            <li><a class="nav-link scrollto" href="{{route('course','linux-administration')}}">Linux & Administration</a></li>
            <li><a class="nav-link scrollto" href="{{route('course','mobailapp-development')}}">Mobile App Development</a></li>
            <li><a class="nav-link scrollto" href="{{route('course','data-science')}}">Data Science</a></li>
            <li><a class="nav-link scrollto" href="{{route('course','data-analysis')}}">Data Analytics</a></li>
            <li><a class="nav-link scrollto" href="{{route('course','machine-learning')}}">AI & Machine Learning</a></li>
            <li><a class="nav-link scrollto" href="{{route('course','cyber-security')}}">Cyber Security</a></li>
        </ul>
    </div>
</div>