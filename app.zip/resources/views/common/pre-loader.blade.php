<!-- <div class="preloader ">
    <button class="th-btn style3 preloaderCls">Cancel Preloader </button>
    <div class="preloader-inner">
        <span class="loader"></span>
    </div>
</div> -->