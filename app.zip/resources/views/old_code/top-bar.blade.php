<section id="topbar" class="d-flex align-items-center fixed-top">
    <div class="container d-flex justify-content-center justify-content-md-between">
        <div class="contact-info d-flex align-items-center ">
            <i class="bi bi-envelope-fill num"></i><a href="mailto:ask@codecruise.in" class="num">ask@codecruise.in</a>
            <!--<i class="bi bi-phone-fill phone-icon num"></i> <span class="num"> (Prefer Email)</span>-->
        </div>
        <div class="social-links d-none d-md-block">
            <a href="https://facebook.com/codecruiseindia/" class="facebook" target="_new"><i
                    class="bi bi-facebook"></i></a>
            <a href="https://instagram.com/codecruise/" class="instagram" target="_new"><i
                    class="bi bi-instagram"></i></a>
            <a href="https://www.linkedin.com/company/codecruise" class="linkedin" target="_new"><i
                    class="bi bi-linkedin"></i></i></a>
            <a href="https://twitter.com/codecruiseindia/" class="twitter" target="_new"><i
                    class="bi bi-twitter"></i></a>
        </div>
    </div>
</section>